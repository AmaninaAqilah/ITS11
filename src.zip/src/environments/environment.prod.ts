export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyC2OuLpjxP2JQeLydOL_yeOsSP-Ah6iDbQ",
    authDomain: "gothrifting-fyp.firebaseapp.com",
    projectId: "gothrifting-fyp",
    storageBucket: "gothrifting-fyp.appspot.com",
    messagingSenderId: "43797455212",
    appId: "1:43797455212:web:6f3245923f6491031c5349"
  }
};
