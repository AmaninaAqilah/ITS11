export interface User {
    userId: string,
    userName: string,
    userEmail: string,
    userPhone: string,
    userPhoto: string,
    createdAt: number
}
