import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-u-filter',
  templateUrl: './u-filter.page.html',
  styleUrls: ['./u-filter.page.scss'],
})
export class UFilterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
