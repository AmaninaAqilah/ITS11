export interface Product {
    id: string;
    itemName: string;
    itemAmount: number;
    itemDescription: string;
    itemCat: string;
    itemGen: string;
    itemQuantity: number;
}
