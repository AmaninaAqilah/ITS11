export interface Vendor {
    vendorId: string;
    vendorName: string;
    vendorEmail: string;
    vendorPhone: string;
    vendorCompany: string;
    vendorPhoto: string;
    createdAt: number;
}
