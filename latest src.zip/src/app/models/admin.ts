export interface Admin {
    adminId: string;
    adminName: string;
    adminEmail: string;
    createdAt: number;
}
