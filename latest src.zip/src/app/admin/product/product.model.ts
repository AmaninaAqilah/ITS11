export class Product{
    constructor(
        public id: string,
        public produtId: string,
        public sellerId: string,
        public productTitle: string,
        public productImage: string,
        public company: string,
        public description: string,

    ){} 
}