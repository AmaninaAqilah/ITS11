import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VendorlogPage } from './vendorlog.page';

const routes: Routes = [
  {
    path: '',
    component: VendorlogPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VendorlogPageRoutingModule {}
