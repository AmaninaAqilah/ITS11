import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendorlog',
  templateUrl: './vendorlog.page.html',
  styleUrls: ['./vendorlog.page.scss'],
})
export class VendorlogPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
