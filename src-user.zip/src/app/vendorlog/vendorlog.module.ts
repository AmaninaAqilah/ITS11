import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VendorlogPageRoutingModule } from './vendorlog-routing.module';

import { VendorlogPage } from './vendorlog.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VendorlogPageRoutingModule
  ],
  declarations: [VendorlogPage]
})
export class VendorlogPageModule {}
