import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Router } from '@angular/router';
import { LoadingController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-vendor-sign-up',
  templateUrl: './vendor-sign-up.page.html',
  styleUrls: ['./vendor-sign-up.page.scss'],
})
export class VendorSignUpPage implements OnInit {

  name: string;
  email: string;
  phone: string;
  cname: string;
  password: string;
  constructor(
    private afs: AngularFirestore,
    private afauth: AngularFireAuth,
    private router: Router,
    private loadingCtrl: LoadingController,
    private toastr: ToastController
  ) { }

  ngOnInit() {
  }

}
